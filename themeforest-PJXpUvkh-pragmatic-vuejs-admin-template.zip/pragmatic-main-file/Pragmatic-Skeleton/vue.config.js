module.exports = {
  lintOnSave: false,
  //baseUrl: '/sub-path/',
  productionSourceMap: false,
  configureWebpack: {
    //entry: ["babel-polyfill", "./src/main.js"]
  }
}