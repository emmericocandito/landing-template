// module.exports = require('./index.vue')
import VuePs from './index.vue'

export default VuePs;