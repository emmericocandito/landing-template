<template>
	<router-view/>
</template>

<script>


export default {
	name: 'Ecommerce'
}
</script>

<style lang="scss" scoped>
</style>

