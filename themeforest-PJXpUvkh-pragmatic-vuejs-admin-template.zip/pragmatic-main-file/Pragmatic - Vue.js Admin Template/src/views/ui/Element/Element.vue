<template>
	<router-view/>
</template>

<script>


export default {
	name: 'Element'
}
</script>

<style lang="scss" scoped>
</style>

