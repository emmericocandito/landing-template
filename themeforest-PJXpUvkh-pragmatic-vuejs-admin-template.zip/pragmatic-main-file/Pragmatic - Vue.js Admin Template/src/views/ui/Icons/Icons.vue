<template>
	<router-view/>
</template>

<script>


export default {
	name: 'Icons'
}
</script>

<style lang="scss" scoped>
</style>

