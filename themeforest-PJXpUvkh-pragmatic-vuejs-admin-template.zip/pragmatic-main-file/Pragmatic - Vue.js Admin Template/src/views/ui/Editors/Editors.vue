<template>
	<router-view/>
</template>

<script>


export default {
	name: 'Editors'
}
</script>

<style lang="scss" scoped>
</style>

