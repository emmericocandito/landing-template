<template>
	<router-view/>
</template>

<script>


export default {
	name: 'Maps'
}
</script>

<style lang="scss" scoped>
</style>

