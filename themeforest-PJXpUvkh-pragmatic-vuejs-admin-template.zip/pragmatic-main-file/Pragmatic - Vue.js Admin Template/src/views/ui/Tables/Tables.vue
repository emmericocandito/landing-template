<template>
	<router-view/>
</template>

<script>


export default {
	name: 'Tables'
}
</script>

<style lang="scss" scoped>
</style>

