<template>
	<router-view/>
</template>

<script>


export default {
	name: 'Charts'
}
</script>

<style lang="scss" scoped>
</style>

