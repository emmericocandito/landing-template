version: 3.2.1

1. Improve some code and fix some design issues.
