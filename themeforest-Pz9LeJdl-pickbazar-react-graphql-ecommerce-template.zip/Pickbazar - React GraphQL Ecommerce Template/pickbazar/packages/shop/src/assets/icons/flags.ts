export { DEFlag } from 'assets/icons/DEFlag';
export { CNFlag } from 'assets/icons/CNFlag';
export { USFlag } from 'assets/icons/USFlag';
export { ILFlag } from 'assets/icons/ILFlag';
export { ESFlag } from 'assets/icons/ESFlag';
export { SAFlag } from 'assets/icons/SAFlag';
