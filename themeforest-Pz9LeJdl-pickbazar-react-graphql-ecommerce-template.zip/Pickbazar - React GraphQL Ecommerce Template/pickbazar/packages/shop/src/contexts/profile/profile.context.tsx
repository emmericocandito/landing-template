import { createContext } from 'react';

export const ProfileContext = createContext<Partial<any>>({});
