import React from 'react';
import Chart from 'react-apexcharts';

const Charts = ({ ...props }) => {
  return <Chart {...props} />;
};

export default Charts;
