class Loader extends React.Component {
    render(){
        return (
            <div className="preloader-wrap">
                <div className="preloader">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>   
            </div>  
        );
    }
}
 
export default Loader;