import App from './App';
import './assets/css/animate.min.css';
import './assets/css//bootstrap.min.css';
import './assets/css/owl.carousel.css';
import './assets/css/fontawesome-all.css';
import './assets/css/flaticon.css';
import './assets/css/meanmenu.css';
import './assets/css/video.min.css';
import './assets/css/lightbox.css';
import './assets/css/progess.css';
//main css
import './assets/css/style.rtl.css';

import './assets/js/bootstrap.min.js';
import './assets/js/jquery-ui.js';
import './assets/js/jarallax.js';
import './assets/js/jquery.magnific-popup.min.js';
import './assets/js/jquery.meanmenu.min.js';

// import './assets/js/switch.js';
import './assets/js/script.js';

module.hot.accept();
